#include <SPI.h>
#include <MFRC522.h>
#include <string.h>

// RFID: D10 pour SDA/SS, A2 pour RST, et le bus SPI standard D11-D13.
constexpr uint8_t RST_PIN = A2;
constexpr uint8_t SS_PIN = 10;
constexpr unsigned long SCAN_COOLDOWN_MS = 700;

// Moteur 1
constexpr uint8_t STEP1_PIN = 6;
constexpr uint8_t DIR1_PIN = 7;

// Moteur 2
constexpr uint8_t STEP2_PIN = 8;
constexpr uint8_t DIR2_PIN = 9;

// Fins de course de fermeture
constexpr uint8_t FC1_FERME_PIN = A5;
constexpr uint8_t FC2_FERME_PIN = A3;

constexpr int PAS_OUVERTURE_M1 = 4500;
constexpr int PAS_OUVERTURE_M2 = 4650;
constexpr int PAS_FERMETURE_MAX_M1 = PAS_OUVERTURE_M1 * 3;
constexpr int PAS_FERMETURE_MAX_M2 = PAS_OUVERTURE_M2 * 3;
constexpr unsigned int DEMI_PERIODE_PAS_US = 600;
constexpr unsigned int DELAI_DIRECTION_US = 20;
constexpr unsigned long ATTENTE_COURTE_MS = 300;
constexpr unsigned long ATTENTE_MOTEUR_2_MS = 2000;

enum EtatCycle : uint8_t {
  REPOS,
  OUVERTURE_M1,
  ATTENTE_APRES_OUVERTURE_M1,
  ATTENTE_RFID,
  FERMETURE_M1_ANNULATION,
  FERMETURE_M1_RFID,
  ATTENTE_APRES_FERMETURE_M1,
  OUVERTURE_M2,
  ATTENTE_APRES_OUVERTURE_M2,
  FERMETURE_M2
};

MFRC522 mfrc522(SS_PIN, RST_PIN);

char lastUid[24] = "";
unsigned long lastScanAt = 0;
unsigned long attenteDepuis = 0;
int pasEffectues = 0;
EtatCycle etatCycle = REPOS;

void envoyerEvenement(const __FlashStringHelper* evenement) {
  Serial.print(F("EVENT:"));
  Serial.println(evenement);
  Serial.flush();
}

void faireUnPas(uint8_t stepPin) {
  digitalWrite(stepPin, HIGH);
  delayMicroseconds(DEMI_PERIODE_PAS_US);
  digitalWrite(stepPin, LOW);
  delayMicroseconds(DEMI_PERIODE_PAS_US);
}

void preparerMouvement(uint8_t dirPin, uint8_t direction, EtatCycle nouvelEtat) {
  digitalWrite(dirPin, direction);
  delayMicroseconds(DELAI_DIRECTION_US);
  pasEffectues = 0;
  etatCycle = nouvelEtat;
}

void demarrerOuvertureMoteur1() {
  preparerMouvement(DIR1_PIN, HIGH, OUVERTURE_M1);
}

void demarrerFermetureMoteur1(EtatCycle nouvelEtat) {
  preparerMouvement(DIR1_PIN, LOW, nouvelEtat);
}

void demarrerOuvertureMoteur2() {
  preparerMouvement(DIR2_PIN, LOW, OUVERTURE_M2);
}

void demarrerFermetureMoteur2() {
  preparerMouvement(DIR2_PIN, HIGH, FERMETURE_M2);
}

bool triggerServo() {
  if (etatCycle != REPOS) {
    return false;
  }

  demarrerOuvertureMoteur1();
  return true;
}

void annulerAttenteRfid() {
  if (
    etatCycle == OUVERTURE_M1 ||
    etatCycle == ATTENTE_APRES_OUVERTURE_M1 ||
    etatCycle == ATTENTE_RFID
  ) {
    demarrerFermetureMoteur1(FERMETURE_M1_ANNULATION);
    return;
  }

  if (etatCycle != FERMETURE_M1_ANNULATION) {
    envoyerEvenement(F("close_ignored_no_active_cycle"));
  }
}

void handleSerialInput() {
  while (Serial.available() > 0) {
    const char commande = static_cast<char>(Serial.read());

    if (commande == 'P' || commande == 'p') {
      envoyerEvenement(F("pong"));
      continue;
    }

    if (commande == 'S' || commande == 's') {
      envoyerEvenement(F("serial_data_received"));
      envoyerEvenement(F("servo_received"));
      if (!triggerServo()) {
        envoyerEvenement(F("servo_ignored_cycle_active"));
      }
      continue;
    }

    if (commande == 'C' || commande == 'c') {
      envoyerEvenement(F("close_received"));
      annulerAttenteRfid();
      continue;
    }

    if (commande != '\r' && commande != '\n' && commande != ' ' && commande != '\t') {
      envoyerEvenement(F("serial_command_unknown"));
    }
  }
}

void terminerFermetureMoteur1(bool annulation) {
  if (annulation) {
    etatCycle = REPOS;
    envoyerEvenement(F("motor1_closed_after_cancel"));
    return;
  }

  attenteDepuis = millis();
  etatCycle = ATTENTE_APRES_FERMETURE_M1;
}

void signalerErreurFinCourse(const __FlashStringHelper* evenement) {
  etatCycle = REPOS;
  envoyerEvenement(evenement);
}

void mettreAJourCycleMoteurs() {
  switch (etatCycle) {
    case REPOS:
    case ATTENTE_RFID:
      return;

    case OUVERTURE_M1:
      if (pasEffectues < PAS_OUVERTURE_M1) {
        faireUnPas(STEP1_PIN);
        pasEffectues++;
        return;
      }
      attenteDepuis = millis();
      etatCycle = ATTENTE_APRES_OUVERTURE_M1;
      return;

    case ATTENTE_APRES_OUVERTURE_M1:
      if (millis() - attenteDepuis >= ATTENTE_COURTE_MS) {
        etatCycle = ATTENTE_RFID;
        envoyerEvenement(F("motor1_opened"));
      }
      return;

    case FERMETURE_M1_ANNULATION:
    case FERMETURE_M1_RFID: {
      const bool annulation = etatCycle == FERMETURE_M1_ANNULATION;
      if (digitalRead(FC1_FERME_PIN) == LOW) {
        terminerFermetureMoteur1(annulation);
        return;
      }
      if (pasEffectues >= PAS_FERMETURE_MAX_M1) {
        signalerErreurFinCourse(F("motor1_limit_not_detected"));
        return;
      }
      faireUnPas(STEP1_PIN);
      pasEffectues++;
      return;
    }

    case ATTENTE_APRES_FERMETURE_M1:
      if (millis() - attenteDepuis >= ATTENTE_COURTE_MS) {
        demarrerOuvertureMoteur2();
      }
      return;

    case OUVERTURE_M2:
      if (pasEffectues < PAS_OUVERTURE_M2) {
        faireUnPas(STEP2_PIN);
        pasEffectues++;
        return;
      }
      attenteDepuis = millis();
      etatCycle = ATTENTE_APRES_OUVERTURE_M2;
      return;

    case ATTENTE_APRES_OUVERTURE_M2:
      if (millis() - attenteDepuis >= ATTENTE_MOTEUR_2_MS) {
        demarrerFermetureMoteur2();
      }
      return;

    case FERMETURE_M2:
      if (digitalRead(FC2_FERME_PIN) == LOW) {
        etatCycle = REPOS;
        envoyerEvenement(F("motor_cycle_complete"));
        return;
      }
      if (pasEffectues >= PAS_FERMETURE_MAX_M2) {
        signalerErreurFinCourse(F("motor2_limit_not_detected"));
        return;
      }
      faireUnPas(STEP2_PIN);
      pasEffectues++;
      return;
  }
}

bool shouldSkipUid(const char* uid) {
  const unsigned long now = millis();
  if (strcmp(lastUid, uid) == 0 && now - lastScanAt < SCAN_COOLDOWN_MS) {
    return true;
  }

  strncpy(lastUid, uid, sizeof(lastUid) - 1);
  lastUid[sizeof(lastUid) - 1] = '\0';
  lastScanAt = now;
  return false;
}

bool printUidAsJson() {
  char uidHex[24];
  uint8_t pos = 0;

  for (byte i = 0; i < mfrc522.uid.size && pos + 2 < sizeof(uidHex); i++) {
    const byte value = mfrc522.uid.uidByte[i];
    const char high = value >> 4;
    const char low = value & 0x0F;

    uidHex[pos++] = high < 10 ? ('0' + high) : ('A' + high - 10);
    uidHex[pos++] = low < 10 ? ('0' + low) : ('A' + low - 10);
  }
  uidHex[pos] = '\0';

  if (shouldSkipUid(uidHex)) {
    return false;
  }

  Serial.print(F("{\"uid\":\""));
  Serial.print(uidHex);
  Serial.println(F("\"}"));
  return true;
}

void lireRfid() {
  if (etatCycle != ATTENTE_RFID || !mfrc522.PICC_IsNewCardPresent()) {
    return;
  }

  if (!mfrc522.PICC_ReadCardSerial()) {
    return;
  }

  const bool nouvellePuce = printUidAsJson();
  mfrc522.PICC_HaltA();
  mfrc522.PCD_StopCrypto1();

  if (nouvellePuce) {
    envoyerEvenement(F("rfid_cycle_started"));
    demarrerFermetureMoteur1(FERMETURE_M1_RFID);
  }
}

void setup() {
  Serial.begin(9600);

  digitalWrite(STEP1_PIN, LOW);
  digitalWrite(STEP2_PIN, LOW);
  pinMode(STEP1_PIN, OUTPUT);
  pinMode(DIR1_PIN, OUTPUT);
  pinMode(STEP2_PIN, OUTPUT);
  pinMode(DIR2_PIN, OUTPUT);

  pinMode(FC1_FERME_PIN, INPUT_PULLUP);
  pinMode(FC2_FERME_PIN, INPUT_PULLUP);

  pinMode(SS_PIN, OUTPUT);
  digitalWrite(SS_PIN, HIGH);
  SPI.begin();
  mfrc522.PCD_Init();

  envoyerEvenement(F("firmware_motor_state_v2"));
  envoyerEvenement(F("arduino_ready"));
}

void loop() {
  handleSerialInput();
  mettreAJourCycleMoteurs();
  lireRfid();
}
